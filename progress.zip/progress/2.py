# bullet power 화면에 보여주기
# 멍멍 소리 다듬어서 넣기
# 시간 비례해서 세지는 mob
# phase 3: 보스전 구현
# 레벨 넘어갈 때 안내문

import pygame
import random
from os import path

img_dir = path.join(path.dirname(__file__), 'img')
snd_dir = path.join(path.dirname(__file__), 'snd')

WIDTH = 480
HEIGHT = 900
FPS = 60

LEVEL_DURATION = 10
NUM_LEVELS = 3

# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# initialize pygame and create window
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SRCALPHA)
pygame.display.set_caption("Corgi run by 20201091 송민경")
clock = pygame.time.Clock()

###images
background = pygame.image.load(path.join(img_dir, "background.png")).convert()
background_rect = background.get_rect()
player_img = pygame.image.load(path.join(img_dir, "corgigi.png")).convert()
player_img.set_colorkey(BLACK)
player_mini_img = pygame.transform.scale(player_img, (25, 30))
player_mini_img.set_colorkey(BLACK)
ghost = pygame.image.load(path.join(img_dir, "sprite_01.png")).convert()
boss = pygame.image.load(path.join(img_dir, "reaper4.png")).convert()
boss.set_colorkey(BLACK)

###sounds
bark_sounds = []
for snd in ['bark1.mp3', 'bark2.mp3']:
    bark_sounds.append(pygame.mixer.Sound(path.join(snd_dir, snd)))
pygame.mixer.music.load(path.join(snd_dir, 'Snowfall.ogg'))
pygame.mixer.music.set_volume(0.4)
pygame.mixer.music.play(loops=-1)

###text
font_name = pygame.font.match_font('congenial black')
def draw_text(surf, text, size, x, y, color=BLACK):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.center = (x, y)
    surf.blit(text_surface, text_rect)

def draw_lives(surf, x, y, lives, img):
    for i in range(lives):
        img_rect = img.get_rect()
        img_rect.x = x + 30 * i
        img_rect.y = y
        surf.blit(img, img_rect)

def Bulletkillmob(mobs, bullets, score):
    hits=pygame.sprite.groupcollide(mobs, bullets, False, True)
    for mob, bullet_list in hits.items():
        for bullet in bullet_list:
            mob.HP -= bullet.HP
            score += bullet.HP
            mob.draw()
            if mob.HP<=0:
                mob.killed()
                score += 100
                Bullet.increase_power(1)

    return score

class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.smoothscale(player_img, (75, 90))
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 0
        self.hidden = False

    def update(self):

        if self.hidden and pygame.time.get_ticks() - self.hide_timer > 1000:
            self.hidden = False
            self.rect.centerx = WIDTH / 2
            self.rect.bottom = HEIGHT - 10

        self.speedx = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_LEFT]:
            self.speedx = -8
        if keystate[pygame.K_RIGHT]:
            self.speedx = 8
        self.rect.x += self.speedx
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0

    def shoot(self):
        bullet = Bullet(self.rect.centerx, self.rect.top)
        all_sprites.add(bullet)
        bullets.add(bullet)
        random.choice(bark_sounds).play()

    def hide(self):
        self.hidden = True
        self.hide_timer = pygame.time.get_ticks()
        self.rect.center = (WIDTH/2, HEIGHT + 200)
        for mob in mobs:
            mob.killed()

class Mob(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(ghost, (70, 70))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(WIDTH - self.rect.width)
        self.rect.y = random.randrange(-100, -40)
        self.speedy = random.randrange(1, 8)
        self.speedx = 0 #random.randrange(-3, 3)
        self.HP = random.randrange(1, 20)
        self.draw()
 
    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 20:
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)

        if self.rect.left <= 0 :
            self.speedx *= -1
        if self.rect.right >= WIDTH :
            self.speedx *= -1

    def killed(self):
        self.kill()
        m= Mob()
        all_sprites.add(m)
        mobs.add(m)

    def draw(self):
        #pygame.draw.rect(screen, RED, (self.rect.x, self.rect.y - 10, self.rect.width, 5))
        draw_text(screen, str(self.HP), 30, self.rect.centerx, self.rect.bottom + 10, BLACK)

class Boss(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(boss, (100,100))
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(WIDTH - self.rect.width)
        self.rect.y = random.randrange(-100, -40)
        self.speedy = random.randrange(1, 3)  # Adjust speed as needed
        self.speedx = random.choice([-2, 2])  # Adjust speed as needed
        self.HP = 500  # Adjust HP as needed

    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 20:
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)

        if self.rect.left <= 0 :
            self.speedx *= -1
        if self.rect.right >= WIDTH :
            self.speedx *= -1

    def draw(self):
        draw_text(screen, str(self.HP), 40, self.rect.centerx, self.rect.bottom + 10, RED)

class Bullet(pygame.sprite.Sprite):
    power =3 

    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((10, 20))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10
        self.HP = Bullet.power

    def update(self):
        self.rect.y += self.speedy

        # kill if it moves off the top of the screen
        if self.rect.bottom < 0:
            self.kill()

    def draw(self):
        draw_text(screen, f"Bullet Power: {self.HP}", 20, WIDTH-150, 5, BLACK)

    @classmethod
    def increase_power(cls, amount):
        cls.power += amount

def show_go_screen():
    screen.blit(background, background_rect)
    draw_text(screen, "Heaven Run!", 64, WIDTH / 2, HEIGHT / 4, BLACK)
    draw_text(screen, "Arrow keys to move, Space to fire", 22,
              WIDTH / 2, HEIGHT / 2)
    draw_text(screen, "Press Space Bar to begin", 18, WIDTH / 2, HEIGHT * 3 / 4)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
                return True
            
def show_game_clear_screen():
    screen.fill(BLACK)
    draw_text(screen, "Game Clear!", 64, WIDTH / 2, HEIGHT / 4, WHITE)
    draw_text(screen, f"Final Score: {score}", 30, WIDTH / 2, HEIGHT / 2, WHITE)
    draw_text(screen, "Press Space Bar to play again", 18, WIDTH / 2, HEIGHT * 3 / 4, WHITE)
    pygame.display.flip()

    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
                waiting = False

###

score, level, life = 0,1,3
all_sprites = pygame.sprite.Group()
mobs = pygame.sprite.Group()
bullets = pygame.sprite.Group()
player = Player()
all_sprites.add(player)
for i in range(5):
    if level < 3:
        m = Mob()
        all_sprites.add(m)
        mobs.add(m)
    else:
        if not any(isinstance(sprite, Boss) for sprite in all_sprites):
            mobs.empty()
            moss = Boss()
            all_sprites.add(boss)
            mobs.add(boss)


# Game loop

def main():

    global all_sprites, mobs, bullets, player, score, level, life

    show_go_screen()

    running = True
    game_over = False
    start_time = pygame.time.get_ticks()
    

    while running:
        clock.tick(FPS)

        if game_over:
            if show_go_screen():
                all_sprites = pygame.sprite.Group()
                mobs = pygame.sprite.Group()
                bullets = pygame.sprite.Group()
                player = Player()
                all_sprites.add(player)
                for i in range(5):
                    m = Mob()
                    all_sprites.add(m)
                    mobs.add(m)
                
                game_over = False
                score = 0
                level =1
                life =3
                start_time = pygame.time.get_ticks()

        for event in pygame.event.get():
            # check for closing window
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.shoot()

        # Update
        all_sprites.update()

        score=Bulletkillmob(mobs, bullets, score)        
    
        # check to see if a mob hit the player
        hits = pygame.sprite.spritecollide(player, mobs, False)
        if hits:
            life -= 1
            player.hide()

            if life == 0:
                game_over = True

        # level up
        elapsed_time = (pygame.time.get_ticks() - start_time) // 1000
        if elapsed_time > LEVEL_DURATION:
            level += 1
            for mob in mobs:
                mob.speedx = random.choice([-3,3])
                if mob.rect.bottom > HEIGHT:
                    mob.killed()
            start_time = pygame.time.get_ticks()
        
        if level == 3:
            if not any(isinstance(sprite, Boss) for sprite in all_sprites):
                mobs.empty()
                boss = Boss()
                all_sprites.add(boss)
                mobs.add(boss)
        
        for sprite in all_sprites:
            if isinstance(sprite, Boss):
                sprite.draw()
        


        # Draw / render
        screen.fill(BLACK)
        screen.blit(background, background_rect)
        draw_text(screen, "score: "+str(score), 40, WIDTH/2, 30, BLACK)

        for mob in mobs:
            mob.draw()
        for bullet in bullets:
            bullet.draw()
        all_sprites.draw(screen)

        draw_lives(screen, WIDTH - 100, 5, life, player_mini_img)


        # *after* drawing everything, flip the display
        pygame.display.flip()


if __name__ == "__main__":
    pygame.init()
    main()
    pygame.quit()

